# HSSAM-Net model skeleton
import torch
import torch.nn as nn

class HSSAMNet(nn.Module):
    def __init__(self, num_classes=1):
        super().__init__()
        # TODO: Add HSSAM, PRA, MaxDP/MaxDUP
    def forward(self, x):
        return x
