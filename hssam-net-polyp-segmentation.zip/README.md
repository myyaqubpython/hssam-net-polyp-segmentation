# HSSAM-Net: Lightweight Polyp Segmentation

PyTorch implementation of HSSAM-Net, a lightweight and efficient U-Net variant for colorectal polyp segmentation.

## Features
- Hyper-Scale Shifted Aggregation Module (HSSAM)
- Progressive Reusing Attention (PRA)
- Max-Diagonal Pooling/Unpooling (MaxDP/MaxDUP)
- Lightweight (~0.9M parameters), real-time (24+ FPS)
- Reproducible training & evaluation on Kvasir-SEG, CVC-ClinicDB, ETIS, CVC-300, EndoCV2020

## Datasets
All datasets used are public:
- [Kvasir-SEG](https://datasets.simula.no/kvasir-seg/)
- [CVC-ClinicDB](https://polyp.grand-challenge.org/CVCClinicDB/)
- [ETIS](http://adas.cvc.uab.es/endoscene)
- [CVC-300](http://mv.cvc.uab.es/projects/colon-qa/cvc-colondb)
- [EndoCV2020](https://endocv2020.grand-challenge.org/)

## Quickstart
```bash
pip install -r requirements.txt
python train.py --config configs/kvasir.yaml
python evaluate.py --config configs/kvasir.yaml --weights runs/kvasir/best.ckpt
```

## License
MIT License
